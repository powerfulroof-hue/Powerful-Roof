import { Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="text-3xl font-bold mb-4">
              <span className="text-orange-500">POWERFUL</span>
              <span className="text-white"> ROOF</span>
              <span className="text-orange-500 text-lg ml-2">LLC</span>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Your trusted partner for all roofing needs. Licensed, insured, and committed 
              to delivering exceptional quality and service to every customer.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-gray-800 hover:bg-orange-500 p-3 rounded-full transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-orange-500 p-3 rounded-full transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-orange-500 p-3 rounded-full transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-orange-500 p-3 rounded-full transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-orange-500">Services</h3>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#" className="hover:text-orange-500 transition-colors">Roof Installation</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Roof Repair</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Roof Inspection</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Gutter Services</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Emergency Repairs</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors">Insurance Claims</a></li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-orange-500">Contact</h3>
            <ul className="space-y-2 text-gray-300">
              <li>(854) 345-2826</li>
              <li>powerfulroof@gmail.com</li>
              <li>Georgia and South Carolina</li>
              <li>Licensed & Insured</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 mb-4 md:mb-0">
              © 2024 Powerful Roof LLC. All rights reserved.
            </p>
            <div className="flex space-x-6 text-gray-400">
              <a href="#" className="hover:text-orange-500 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-orange-500 transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-orange-500 transition-colors">Warranty</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
