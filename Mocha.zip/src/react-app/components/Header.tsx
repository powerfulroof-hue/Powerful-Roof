import { Phone, Mail, MapPin } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-black text-white">
      {/* Top contact bar */}
      <div className="bg-orange-500">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex flex-col sm:flex-row justify-between items-center text-sm">
            <div className="flex items-center space-x-4 mb-2 sm:mb-0">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>(854) 345-2826</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>powerfulroof@gmail.com</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4" />
              <span>Serving Georgia and South Carolina</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main navigation */}
      <nav className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="text-2xl font-bold">
            <span className="text-orange-500">POWERFUL</span>
            <span className="text-white"> ROOF</span>
            <span className="text-orange-500 text-sm ml-2">LLC</span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#home" className="hover:text-orange-500 transition-colors">Home</a>
            <a href="#services" className="hover:text-orange-500 transition-colors">Services</a>
            <a href="#about" className="hover:text-orange-500 transition-colors">About</a>
            <a href="#contact" className="hover:text-orange-500 transition-colors">Contact</a>
          </div>
          
          <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded-lg font-semibold transition-colors">
            Free Estimate
          </button>
        </div>
      </nav>
    </header>
  );
}
