import { Home, Wrench, Droplets, Eye } from 'lucide-react';

const services = [
  {
    icon: Home,
    title: "Roof Installation",
    description: "Complete roof replacement with premium materials and expert installation techniques.",
    features: ["Asphalt Shingles", "Metal Roofing", "Tile Installation", "Flat Roofing"]
  },
  {
    icon: Wrench,
    title: "Roof Repair",
    description: "Fast and reliable repairs to fix leaks, damaged shingles, and storm damage.",
    features: ["Leak Repair", "Shingle Replacement", "Storm Damage", "Flashing Repair"]
  },
  {
    icon: Droplets,
    title: "Gutter Services",
    description: "Professional gutter installation, repair, and maintenance services.",
    features: ["Gutter Installation", "Gutter Cleaning", "Downspout Repair", "Gutter Guards"]
  },
  {
    icon: Eye,
    title: "Roof Inspection",
    description: "Comprehensive roof inspections to identify issues before they become problems.",
    features: ["Free Estimates", "Insurance Claims", "Damage Assessment", "Maintenance Plans"]
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4">
            Our <span className="text-orange-500">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From new installations to emergency repairs, we provide comprehensive roofing solutions 
            tailored to your needs and budget.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow p-8 group">
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <service.icon className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-black mb-4">{service.title}</h3>
              <p className="text-gray-600 mb-6">{service.description}</p>
              
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-gray-700">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>
              
              <button className="mt-6 w-full bg-black hover:bg-gray-800 text-white py-3 rounded-lg font-semibold transition-colors">
                Learn More
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
