import { Shield, Award, Clock } from 'lucide-react';

export default function Hero() {
  return (
    <section 
      id="home" 
      className="relative bg-cover bg-center bg-no-repeat min-h-screen flex items-center"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('https://mocha-cdn.com/01987c0f-eef4-7b58-91be-7524a62ef30d/powerful-roof-logo.jpg')`
      }}
    >
      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="max-w-3xl text-white">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="text-orange-500">POWERFUL</span> ROOFING
            <br />
            <span className="text-4xl md:text-5xl">SOLUTIONS</span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-gray-200">
            Professional roofing services you can trust. From installations to repairs, 
            we deliver quality workmanship that protects your investment.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
              Get Free Estimate
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-black px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
              View Our Work
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-center space-x-3">
              <div className="bg-orange-500 p-3 rounded-full">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Licensed & Insured</h3>
                <p className="text-gray-300">Fully bonded professionals</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="bg-orange-500 p-3 rounded-full">
                <Award className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Quality Guarantee</h3>
                <p className="text-gray-300">Workmanship warranty</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="bg-orange-500 p-3 rounded-full">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">24/7 Emergency</h3>
                <p className="text-gray-300">Always here when you need us</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
