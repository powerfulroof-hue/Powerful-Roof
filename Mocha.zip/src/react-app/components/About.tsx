import { Users, Calendar, Trophy, MapPin } from 'lucide-react';

const stats = [
  { icon: Calendar, number: "15+", label: "Years Experience" },
  { icon: Users, number: "500+", label: "Happy Customers" },
  { icon: Trophy, number: "1000+", label: "Projects Completed" },
  { icon: MapPin, number: "50+", label: "Service Areas" }
];

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
              Why Choose <span className="text-orange-500">Powerful Roof</span>?
            </h2>
            
            <p className="text-xl text-gray-600 mb-8">
              For over 15 years, Powerful Roof LLC has been the trusted choice for residential 
              and commercial roofing solutions. Our commitment to excellence and customer 
              satisfaction sets us apart in the industry.
            </p>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4">
                <div className="bg-orange-500 p-2 rounded-full mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-black mb-2">Expert Craftsmanship</h3>
                  <p className="text-gray-600">Our skilled professionals deliver superior workmanship on every project.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="bg-orange-500 p-2 rounded-full mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-black mb-2">Premium Materials</h3>
                  <p className="text-gray-600">We use only the highest quality materials from trusted manufacturers.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="bg-orange-500 p-2 rounded-full mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-black mb-2">Customer Focused</h3>
                  <p className="text-gray-600">Your satisfaction is our priority. We work with you every step of the way.</p>
                </div>
              </div>
            </div>
            
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
              Contact Us Today
            </button>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600&h=800&fit=crop" 
              alt="Beautiful modern house with quality roofing" 
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-8 -left-8 bg-black text-white p-8 rounded-xl shadow-xl">
              <h3 className="text-2xl font-bold mb-2">Licensed & Insured</h3>
              <p className="text-gray-300">Your protection is our guarantee</p>
            </div>
          </div>
        </div>
        
        {/* Stats Section */}
        <div className="mt-20 bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl p-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center text-white">
            {stats.map((stat, index) => (
              <div key={index} className="space-y-4">
                <div className="flex justify-center">
                  <stat.icon className="w-12 h-12" />
                </div>
                <div className="text-4xl font-bold">{stat.number}</div>
                <div className="text-lg text-orange-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
